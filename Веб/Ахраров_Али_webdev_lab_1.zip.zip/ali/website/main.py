from starlette.middleware.sessions import SessionMiddleware
from fastapi.staticfiles import StaticFiles
from jose import jwt
from passlib.context import CryptContext
from motor.motor_asyncio import AsyncIOMotorClient
from odmantic import AIOEngine, Model
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi import FastAPI, Request, Form, Depends, HTTPException
import os

# Конфигурация секретного ключа и алгоритма для JWT
SECRET_KEY = "aliahrarov"
ALGORITHM = "HS256"

# Создание экземпляра приложения FastAPI
app = FastAPI()

# Поддержка сессий
app.add_middleware(SessionMiddleware, secret_key=SECRET_KEY)

# Настройка контекста для хэширования паролей с использованием bcrypt
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Функция для хэширования пароля
def encrypt_password(password: str):
    return pwd_context.hash(password)

# Функция для проверки пароля на соответствие хэшу
def check_password(plain_password, stored_password):
    return pwd_context.verify(plain_password, stored_password)

# Настройка подключения к MongoDB через ODMantic
client = AsyncIOMotorClient("mongodb://ahrarov:ali@db:27017/users_db")
engine = AIOEngine(client=client, database="users_db")

# Определение модели пользователя для MongoDB
class User(Model):
    login: str
    hashed_password: str

# Определение модели чата для MongoDB
class Chat(Model):
    chat_name: str

# Путь к папке с шаблонами HTML
templates = Jinja2Templates(directory="frontend")

# Функция для создания JWT токена доступа
def generate_token(data: dict):
    to_encode = data.copy()
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

# Маршрут для главной страницы
@app.get("/", response_class=HTMLResponse)
async def main_page(request: Request):
    # Проверка на наличие пользователя в сессии
    if request.session.get("user"):
        return templates.TemplateResponse("mainpage.html", {"request": request, "user": request.session.get("user")})
    return templates.TemplateResponse("mainpage.html", {"request": request})

# Маршрут для отображения страницы входа
@app.get("/login", response_class=HTMLResponse)
async def show_login(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

# Маршрут для обработки формы входа
@app.post("/login", response_class=HTMLResponse)
async def process_login(request: Request, email: str = Form(...), password: str = Form(...)):
    # Поиск пользователя в базе данных по логину (email)
    user = await engine.find_one(User, User.login == email)
    # Проверка соответствия пароля
    if not user or not check_password(password, user.hashed_password):
        return templates.TemplateResponse("login.html", {"request": request, "error": "Неверные данные для входа."})
    # Сохранение пользователя в сессии
    request.session["user"] = user.login
    return RedirectResponse("/choice", status_code=302)

# Маршрут для выхода из системы
@app.get("/logout")
async def process_logout(request: Request):
    # Удаление пользователя из сессии
    request.session.pop("user", None)
    return RedirectResponse("/", status_code=302)

# Маршрут для отображения страницы выбора действий
@app.get("/choice", response_class=HTMLResponse)
async def action_choice(request: Request):
    # Проверка на наличие пользователя в сессии
    if not request.session.get("user"):
        return RedirectResponse("/login", status_code=302)
    return templates.TemplateResponse("choice.html", {"request": request})

# Маршрут для отображения страницы создания чата
@app.get("/create_chat", response_class=HTMLResponse)
async def show_create_chat(request: Request):
    # Проверка на наличие пользователя в сессии
    if not request.session.get("user"):
        return RedirectResponse("/login", status_code=302)
    return templates.TemplateResponse("create_chat.html", {"request": request})

# Маршрут для обработки создания нового чата
@app.post("/create_chat", response_class=HTMLResponse)
async def process_create_chat(request: Request, chat_name: str = Form(...)):
    # Проверка на наличие пользователя в сессии
    if not request.session.get("user"):
        return RedirectResponse("/login", status_code=302)

    # Проверка минимальной длины названия чата
    if len(chat_name) < 6:
        return templates.TemplateResponse("create_chat.html", {"request": request, "error": "Название беседы должно содержать минимум 6 символов."})

    # Проверка на существование чата с таким же названием
    existing_chat = await engine.find_one(Chat, Chat.chat_name == chat_name)
    if existing_chat:
        return templates.TemplateResponse("create_chat.html", {"request": request, "error": "Беседа с таким названием уже существует."})

    # Создание нового чата и сохранение в базе данных
    chat = Chat(chat_name=chat_name, messages=[])
    await engine.save(chat)

    return RedirectResponse(url=f"/chat_view/{chat_name}", status_code=303)

# Маршрут для отображения страницы поиска чатов
@app.get("/search_chat", response_class=HTMLResponse)
async def show_search_chat(request: Request):
    # Проверка на наличие пользователя в сессии
    if not request.session.get("user"):
        return RedirectResponse("/login", status_code=302)

    # Получение списка всех чатов из базы данных
    chats = await engine.find(Chat)
    return templates.TemplateResponse("search_chat.html", {"request": request, "chats": chats})

# Маршрут для обработки поиска чатов по запросу
@app.post("/search_chat", response_class=HTMLResponse)
async def process_search_chats(request: Request, query: str = Form(...)):
    # Проверка на наличие пользователя в сессии
    if not request.session.get("user"):
        return RedirectResponse("/login", status_code=302)

    # Проверка минимальной длины запроса
    if len(query) < 6:
        return templates.TemplateResponse("search_chat.html", {"request": request, "error": "Запрос должен содержать минимум 6 символов."})

    # Поиск чатов, соответствующих запросу
    chats = await engine.find(Chat, Chat.chat_name.match(query))
    return templates.TemplateResponse("search_chat.html", {"request": request, "chats": chats, "query": query})

# Маршрут для отображения страницы регистрации
@app.get("/register", response_class=HTMLResponse)
async def show_register(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})

# Маршрут для обработки формы регистрации
@app.post("/register", response_class=HTMLResponse)
async def process_register(request: Request, email: str = Form(...), password: str = Form(...)):
    # Проверка на существование пользователя с таким же логином
    existing_account = await engine.find_one(User, User.login == email)
    if existing_account:
        return templates.TemplateResponse("register.html", {"request": request, "error": "Пользователь с таким email уже существует."})

    # Хэширование пароля и создание нового пользователя
    hashed_password = encrypt_password(password)
    user = User(login=email, hashed_password=hashed_password)
    await engine.save(user)

    # Сохранение пользователя в сессии
    request.session["user"] = user.login
    return RedirectResponse("/choice", status_code=302)

# Маршрут для удаления чата
@app.post("/deletechat/{chat_name}")
async def process_delete_chat(chat_name: str, request: Request):
    # Проверка на наличие пользователя в сессии
    if not request.session.get("user"):
        return RedirectResponse("/login", status_code=302)

    # Поиск чата в базе данных
    chat_to_delete = await engine.find_one(Chat, Chat.chat_name == chat_name)

    # Удаление чата, если он найден
    if chat_to_delete:
        await engine.delete(chat_to_delete)
        return RedirectResponse("/choice", status_code=303)
    else:
        return templates.TemplateResponse("chat_view.html", {"request": request, "error": "Беседа не найдена."})

# Маршрут для отображения страницы чата
@app.get("/chat_view/{chat_name}", response_class=HTMLResponse)
async def show_chat_page(request: Request, chat_name: str):
    # Проверка на наличие пользователя в сессии
    if not request.session.get("user"):
        return RedirectResponse("/login", status_code=302)
    
    # Получение данных пользователя и генерация токена доступа
    user = request.session.get("user")
    token = generate_token({"sub": user})
    
    return templates.TemplateResponse("chat_view.html", {"request": request, "chat_name": chat_name, "user": user, "token": token})
