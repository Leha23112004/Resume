1) Обычный запуск: 

    ```./lab12araN3250 /home ```
2) Запуск в режиме дебага: 

    ```LAB11DEBUG=1 ./lab12araN3250 /home ```
3) Запуск с валгриндом: 

    ```valgrind --leak-check=full --show-leak-kinds=all --track-origins=yes --verbose --log-file=valgrind-out.txt ./lab12araN3250 --mac-addr-bin a0:12:ce:78:9f:b4 /home```