Чтобы получить отчёт valgrind перед запуском программы с параметрами пишем:
valgrind --leak-check=full --show-leak-kinds=all --track-origins=yes --verbose --log-file=valgrind-out.txt

Например
valgrind --leak-check=full --show-leak-kinds=all --track-origins=yes --verbose --log-file=valgrind-out.txt ./lab11araN3250 /home 0x73747564656e74

Или для дебаг режима
LAB11DEBUG=1 valgrind --leak-check=full --show-leak-kinds=all --track-origins=yes --verbose --log-file=valgrind-out.txt ./lab11araN3250 /home 0x73747564656e74
